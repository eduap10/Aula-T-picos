<?php
// Recebe o nome do usuário via URL
$nome = isset($_GET['nome']) ? htmlspecialchars($_GET['nome']) : "Visitante";
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <title>Página Inicial</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background: linear-gradient(135deg, #74ebd5, #ACB6E5);
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
        }

        .welcome-container {
            background: #ffffff;
            padding: 40px 60px;
            border-radius: 15px;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
            text-align: center;
        }

        h1 {
            color: #34495e;
        }

        p {
            font-size: 18px;
            color: #2c3e50;
        }

        a {
            display: inline-block;
            margin-top: 20px;
            padding: 10px 20px;
            background-color: #1abc9c;
            color: white;
            text-decoration: none;
            border-radius: 8px;
            transition: background-color 0.3s ease;
        }

        a:hover {
            background-color: #16a085;
        }
    </style>
</head>
<body>

<div class="welcome-container">
    <h1>Bem-vindo, <?php echo $nome; ?>!</h1>
    <p>Você acessou a página inicial com sucesso.</p>
    <a href="login.php">Sair</a>
</div>

</body>
</html>
